mediawiki-moderation
====================

Extension:Moderation is a powerful anti-spam extension for MediaWiki CMS.
It protects small/medium wikis against vandalism.

This extension sends all edits and uploads from new users to moderation.

See https://mediawiki.org/wiki/Extension:Moderation for more information.
