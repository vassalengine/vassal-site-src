RENAME TABLE /*_*/hitcounter TO /*_*/hit_counter_extension;
