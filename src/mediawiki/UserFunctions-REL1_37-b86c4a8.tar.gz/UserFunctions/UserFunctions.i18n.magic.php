<?php

$magicWords = [];

/** English (English) */
$magicWords['en'] = [
	'ifanon'    => [ 0, 'ifanon' ],
	'ifblocked' => [ 0, 'ifblocked' ],
	'ifsysop'   => [ 0, 'ifsysop' ],
	'realname'  => [ 0, 'realname' ],
	'username'  => [ 0, 'username' ],
	'useremail' => [ 0, 'useremail' ],
	'nickname'  => [ 0, 'nickname' ],
	'ifingroup' => [ 0, 'ifingroup' ],
	'ip'        => [ 0, 'ip' ],
];
