<?php

$magicWords = array();

/** English (English) */
$magicWords['en'] = array(
	'ifanon'    => array( 0, 'ifanon' ),
	'ifblocked' => array( 0, 'ifblocked' ),
	'ifsysop'   => array( 0, 'ifsysop' ),
	'realname'  => array( 0, 'realname' ),
	'username'  => array( 0, 'username' ),
	'useremail' => array( 0, 'useremail' ),
	'nickname'  => array( 0, 'nickname' ),
	'ifingroup' => array( 0, 'ifingroup' ),
	'ip'        => array( 0, 'ip' ),
);
