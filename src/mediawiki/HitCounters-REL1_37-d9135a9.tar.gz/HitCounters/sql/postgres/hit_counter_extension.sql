CREATE unlogged TABLE /*_*/hit_counter_extension (
  hc_id integer NOT NULL
);